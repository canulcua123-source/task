
CREATE SCHEMA IF NOT EXISTS claudent;
SET search_path TO claudent;

CREATE TABLE rol (
 id_rol SERIAL PRIMARY KEY,
 nombre_rol VARCHAR(50) NOT NULL UNIQUE,
 descripcion VARCHAR(200)
);

CREATE TABLE usuario (
 id_usuario SERIAL PRIMARY KEY,
 id_rol INT NOT NULL REFERENCES rol(id_rol),
 nombre_usuario VARCHAR(80) NOT NULL,
 correo VARCHAR(120) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 estado VARCHAR(20) DEFAULT 'ACTIVO',
 CHECK(estado IN ('ACTIVO','INACTIVO'))
);

CREATE TABLE especialidad (
 id_especialidad SERIAL PRIMARY KEY,
 nombre_especialidad VARCHAR(100) NOT NULL UNIQUE,
 descripcion VARCHAR(200)
);

CREATE TABLE dentista (
 id_dentista SERIAL PRIMARY KEY,
 id_especialidad INT NOT NULL REFERENCES especialidad(id_especialidad),
 nombre VARCHAR(80) NOT NULL,
 apellido VARCHAR(80) NOT NULL,
 telefono VARCHAR(15) UNIQUE,
 correo VARCHAR(120) UNIQUE,
 cedula_profesional VARCHAR(50) UNIQUE
);

CREATE TABLE paciente (
 id_paciente SERIAL PRIMARY KEY,
 nombre VARCHAR(80) NOT NULL,
 apellido VARCHAR(80) NOT NULL,
 fecha_nacimiento DATE,
 telefono VARCHAR(15) UNIQUE,
 correo VARCHAR(120) UNIQUE,
 direccion VARCHAR(200),
 fecha_registro DATE DEFAULT CURRENT_DATE
);

CREATE TABLE servicio (
 id_servicio SERIAL PRIMARY KEY,
 nombre_servicio VARCHAR(100) NOT NULL UNIQUE,
 descripcion VARCHAR(250),
 costo NUMERIC(10,2) NOT NULL CHECK(costo > 0),
 estado VARCHAR(20) DEFAULT 'ACTIVO',
 CHECK(estado IN ('ACTIVO','INACTIVO'))
);

CREATE TABLE cita (
 id_cita SERIAL PRIMARY KEY,
 id_paciente INT NOT NULL REFERENCES paciente(id_paciente),
 id_dentista INT NOT NULL REFERENCES dentista(id_dentista),
 fecha_cita DATE NOT NULL,
 hora_cita TIME NOT NULL,
 motivo VARCHAR(200),
 estado VARCHAR(20) DEFAULT 'PROGRAMADA',
 CHECK(estado IN ('PROGRAMADA','ATENDIDA','CANCELADA'))
);

CREATE TABLE consulta (
 id_consulta SERIAL PRIMARY KEY,
 id_cita INT NOT NULL REFERENCES cita(id_cita),
 id_servicio INT NOT NULL REFERENCES servicio(id_servicio),
 diagnostico VARCHAR(300),
 observaciones VARCHAR(300),
 fecha_consulta DATE DEFAULT CURRENT_DATE
);

CREATE TABLE pago (
 id_pago SERIAL PRIMARY KEY,
 id_consulta INT NOT NULL REFERENCES consulta(id_consulta),
 monto NUMERIC(10,2) NOT NULL CHECK(monto > 0),
 metodo_pago VARCHAR(30) NOT NULL,
 fecha_pago DATE DEFAULT CURRENT_DATE,
 CHECK(metodo_pago IN ('EFECTIVO','TRANSFERENCIA','TARJETA'))
);

CREATE TABLE bitacora_auditoria (
 id_bitacora SERIAL PRIMARY KEY,
 id_usuario INT REFERENCES usuario(id_usuario),
 operacion VARCHAR(20) NOT NULL,
 tabla_afectada VARCHAR(50) NOT NULL,
 fecha_evento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 descripcion TEXT
);
